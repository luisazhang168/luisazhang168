'use strict';
// Meta Pixel: public pages only; no advanced matching or automatic form events.
if (!window.location.pathname.startsWith('/admin') && !window.fbq) {
  const fbq = window.fbq = function () {
    if (fbq.callMethod) fbq.callMethod.apply(fbq, arguments);
    else fbq.queue.push(arguments);
  };
  if (!window._fbq) window._fbq = fbq;
  fbq.push = fbq;
  fbq.loaded = true;
  fbq.version = '2.0';
  fbq.queue = [];
  fbq('set', 'autoConfig', false, '1406803950899656');
  fbq('init', '1406803950899656');
  fbq('track', 'PageView');
  const pixelScript = document.createElement('script');
  pixelScript.async = true;
  pixelScript.src = 'https://connect.facebook.net/en_US/fbevents.js';
  document.head.appendChild(pixelScript);
}
const site = window.SITE || {};
const menu = document.querySelector('.menu');
const nav = document.querySelector('#navigation');
menu.addEventListener('click', () => { const open = menu.getAttribute('aria-expanded') !== 'true'; menu.setAttribute('aria-expanded', String(open)); nav.classList.toggle('open', open); });
document.addEventListener('keydown', e => { if(e.key === 'Escape') { nav.classList.remove('open'); menu.setAttribute('aria-expanded', 'false'); } });
document.querySelector('#year').textContent = new Date().getFullYear();
document.querySelectorAll('[data-company]').forEach(el => { el.textContent = site.company || 'JINAN INNO MACHINERY TECHNOLOGY CO., LTD.'; });
const validEmail = typeof site.email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(site.email);
const phone = String(site.whatsapp || '').replace(/[^0-9]/g, '');
const validPhone = phone.length >= 7 && phone.length <= 15;
function contact(id, missing, value, url) {const el = document.getElementById(id); if(el && value) {el.textContent = value;el.href = url;document.getElementById(missing).hidden=true;}}
if(validEmail) contact('email-link','email-missing',site.email,'mailto:'+site.email);
if(validPhone) contact('whatsapp-link','whatsapp-missing',(phone==='8618953194829'?'+86 18953194829':'+'+phone),'https://wa.me/'+phone);
if(site.address && document.getElementById('address-text')) document.getElementById('address-text').textContent=site.address;
document.querySelector('.mobile-contact').classList.add('enabled');
function safeImage(path){return typeof path === 'string' && /^(assets\/|\/media\/)[a-zA-Z0-9_./-]+\.(jpe?g|png|webp|avif)$/i.test(path) && !path.includes('..');}
function photo(id,path,alt){const box=document.getElementById(id);if(!box || !safeImage(path))return;const img=new Image();img.className='photo';img.alt=alt;img.onload=()=>box.replaceChildren(img);img.src=path;}
photo('hero-media',site.heroImage,'JINAN INNO MACHINERY TECHNOLOGY CO., LTD. continuous waste plastic pyrolysis equipment');
photo('factory-media',site.factoryImage,'JINAN INNO MACHINERY TECHNOLOGY CO., LTD. equipment facility');
const grid=document.getElementById('projects-grid');
if(grid && Array.isArray(site.projects)) {
  site.projects.filter(p=>p.title && p.description).forEach(p=>{const article=document.createElement('article');article.className='project-card';if(safeImage(p.image)){const img=new Image();img.src=p.image;img.alt=p.imageAlt || p.title;img.loading='lazy';img.onerror=()=>img.remove();article.append(img);}const content=document.createElement('div');content.className='panel';const label=document.createElement('div');label.className='eyebrow';label.textContent=p.location || 'Project reference';const title=document.createElement('h3');title.textContent=p.title;const para=document.createElement('p');para.textContent=p.description;content.append(label,title,para);if(p.capacity){const capacity=document.createElement('p');capacity.textContent='Processing capacity: '+p.capacity;content.append(capacity);}article.append(content);grid.append(article);});
  if(grid.children.length)document.getElementById('projects-empty').hidden=true;
}
const form=document.getElementById('enquiry-form');
if(form){let submissionId=crypto.randomUUID();form.addEventListener('submit',async e=>{e.preventDefault();if(!form.reportValidity())return;const button=form.querySelector('[type=submit]');const status=document.getElementById('form-status');button.disabled=true;status.textContent='Sending your enquiry…';try{const data=Object.fromEntries(new FormData(form));const response=await fetch('/api/enquiries',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...data,id:submissionId})});const result=await response.json();if(!response.ok)throw new Error(result.error||'Unable to send. Please try again.');status.textContent='Thank you. Your enquiry has been received. We will contact you using the email address you provided.';form.reset();submissionId=crypto.randomUUID();}catch(error){status.textContent=error.message||'Unable to send. Your input is preserved. Please try again or contact us by email.';}finally{button.disabled=false;}});}

const galleryLinks=document.querySelectorAll('.gallery-photo');
if(galleryLinks.length){
 const viewer=document.createElement('dialog');viewer.className='image-viewer';viewer.setAttribute('aria-label','Equipment photograph');
 const close=document.createElement('button');close.type='button';close.textContent='Close ×';
 const large=new Image();const caption=document.createElement('p');viewer.append(close,large,caption);document.body.append(viewer);
 close.addEventListener('click',()=>viewer.close());viewer.addEventListener('click',event=>{if(event.target===viewer)viewer.close();});
 galleryLinks.forEach(link=>link.addEventListener('click',event=>{if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;event.preventDefault();large.src=link.href;large.alt=link.dataset.caption;caption.textContent=link.dataset.caption;viewer.showModal();}));
}
