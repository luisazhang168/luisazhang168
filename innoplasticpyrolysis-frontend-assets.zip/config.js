window.SITE = {
  company: 'JINAN INNO MACHINERY TECHNOLOGY CO., LTD.',
  email: 'salesluisa@163.com',
  whatsapp: '8618953194829',
  address: 'NO.30,LISHAN ROAD, LIXIA DISTRICT, SHANDONG, CHINA.',
  heroImage: 'assets/equipment-11.jpg',
  factoryImage: 'assets/equipment-8.jpg',
  projects: []
};
