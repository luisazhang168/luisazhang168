# Meta enquiry conversion delivery

Pixel: 1406803950899656. Event: Lead. Only new, valid enquiries with the optional Meta consent checkbox selected are queued. No historical enquiries are exported. The token must be configured as the server secret META_CAPI_ACCESS_TOKEN; it must never be committed to GitHub.

Payload includes a SHA-256 normalized email hash, browser user agent, request IP when supplied by the hosting edge, and existing valid _fbp/_fbc cookies. It excludes enquiry text, name, capacity and country. Hashing is matching, not anonymization. The form discloses this optional sharing.

The enquiry and event are stored in one database batch. Delivery is asynchronous after the request. Failure does not discard the enquiry. Pending events retry on subsequent website requests with 1 minute to 1 hour backoff, retaining the original event ID and time. There is no independent timer: without new traffic, retries wait for a later visit. Events older than six days expire. Matching data is erased after success or expiry. A scheduled queue worker can be added separately if traffic-independent retries are needed.

Only the server sends Lead; the browser currently sends PageView, so no duplicate browser Lead is created. event_id equals the unique enquiry ID, including on retries.

For Meta's Test Events, optionally configure META_CAPI_TEST_EVENT_CODE in the server environment and redeploy; remove it and redeploy before production. Verify events_received=1 and the Test Events UI before claiming end-to-end verification. No token has been configured by the implementation itself.
