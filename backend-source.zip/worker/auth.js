const SESSION_COOKIE='__Host-inno_admin';
const hex=bytes=>Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
const sha=async value=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)));
function sessionToken(req){return req.headers.get('cookie')?.split(';').map(v=>v.trim()).find(v=>v.startsWith(SESSION_COOKIE+'='))?.slice(SESSION_COOKIE.length+1)||'';}
async function admin(req,env){
 const token=sessionToken(req);if(!/^[a-f0-9]{64}$/.test(token)||!env.ADMIN_PASSWORD_HASH)return false;
 const row=await db(env).prepare('SELECT credential_tag,expires FROM admin_sessions WHERE token_hash=?').bind(await sha(token)).first();
 return !!row&&row.expires>Date.now()&&row.credential_tag===await sha(env.ADMIN_PASSWORD_HASH);
}
async function passwordMatches(password,stored){
 const [salt,expected]=stored.split(':');if(!/^[a-f0-9]{32}$/.test(salt)||!/^[a-f0-9]{64}$/.test(expected))fail(503,'登录服务暂不可用');
 const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
 const saltBytes=Uint8Array.from(salt.match(/../g),v=>parseInt(v,16));
 const actual=hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:saltBytes,iterations:100000},material,256));
 let difference=0;for(let i=0;i<64;i++)difference|=actual.charCodeAt(i)^expected.charCodeAt(i);return difference===0;
}
function loginPage(){return new Response('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><link rel="stylesheet" href="/admin.css"><script src="/admin-login.js" defer></script><title>网站管理登录</title></head><body><main class="login"><h1>INNO 网站管理</h1><p>登录后修改网站内容、图片并查看客户留言。</p><form id="admin-login"><label>账号<input name="username" autocomplete="username" required maxlength="80"></label><label style="margin:20px 0">密码<input name="password" type="password" autocomplete="current-password" required maxlength="200"></label><button type="submit">登录后台</button><p id="login-status" role="status" aria-live="polite"></p></form><p><a href="/">返回网站</a></p></main></body></html>',{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-frame-options':'DENY'}});}
async function login(req,env){
 if(!env.ADMIN_PASSWORD_HASH||!env.ADMIN_USERNAME)fail(503,'登录服务暂不可用');
 const b=await body(req,2048);if(typeof b.username!=='string'||typeof b.password!=='string'||b.username.length>80||b.password.length>200)fail(400,'账号或密码格式不正确');
 const window=Math.floor(Date.now()/900000);const ip=req.headers.get('cf-connecting-ip')||'unknown';
 const key='login:'+await sha(ip+':'+window);
 const count=await db(env).prepare('INSERT INTO submission_limits (key,count,expires) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(key,(window+2)*900000).first();
 if(count.count>10)fail(429,'登录尝试过多，请15分钟后再试');
 const valid=await passwordMatches(b.password,env.ADMIN_PASSWORD_HASH);
 if(!valid||b.username!==env.ADMIN_USERNAME)fail(401,'账号或密码不正确');
 const old=sessionToken(req);if(/^[a-f0-9]{64}$/.test(old))await db(env).prepare('DELETE FROM admin_sessions WHERE token_hash=?').bind(await sha(old)).run();
 const token=hex(crypto.getRandomValues(new Uint8Array(32)));
 await db(env).prepare('INSERT INTO admin_sessions (token_hash,credential_tag,expires) VALUES (?,?,?)').bind(await sha(token),await sha(env.ADMIN_PASSWORD_HASH),Date.now()+8*3600000).run();
 await db(env).prepare('DELETE FROM admin_sessions WHERE expires < ?').bind(Date.now()).run();
 await db(env).prepare('DELETE FROM submission_limits WHERE expires < ?').bind(Date.now()).run();
 const res=json({ok:true});res.headers.set('Set-Cookie',`${SESSION_COOKIE}=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=28800`);return res;
}
async function logout(req,env){const token=sessionToken(req);if(/^[a-f0-9]{64}$/.test(token))await db(env).prepare('DELETE FROM admin_sessions WHERE token_hash=?').bind(await sha(token)).run();const res=json({ok:true});res.headers.set('Set-Cookie',`${SESSION_COOKIE}=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0`);return res;}
