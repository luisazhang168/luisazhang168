// Server-only Meta Conversions API. Token is supplied by the hosting environment.
const META_PIXEL_ID = '1406803950899656';
async function capiEvent(req, b) {
 const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(b.email.trim().toLowerCase()));
 const user = {em:[Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('')]};
 const ip=req.headers.get('cf-connecting-ip'),ua=req.headers.get('user-agent');
 if(ip)user.client_ip_address=ip;if(ua)user.client_user_agent=ua.slice(0,1000);
 for(const key of ['fbp','fbc']){const value=(req.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('_'+key+'='))?.slice(key.length+2);if(value&&/^fb\.\d+\.\d+\.[A-Za-z0-9._-]+$/.test(value)&&value.length<=500)user[key]=value;}
 return {event_name:'Lead',event_id:b.id,event_time:Math.floor(Date.now()/1000),action_source:'website',event_source_url:'https://innoplasticpyrolysis.com/contact',user_data:user};
}
async function drainCapi(env) {
 if(!env.META_CAPI_ACCESS_TOKEN)return;
 const now=Date.now();
 // Expired matching data is removed, while delivery status remains available.
 await db(env).prepare("UPDATE capi_outbox SET status='expired',payload='{}' WHERE status='pending' AND created_at < ?").bind(now-6*86400000).run();
 const rows=await db(env).prepare("SELECT * FROM capi_outbox WHERE status='pending' AND next_attempt<=? ORDER BY created_at LIMIT 3").bind(now).all();
 for(const row of rows.results){
  const lock=await db(env).prepare("UPDATE capi_outbox SET next_attempt=?,attempts=attempts+1 WHERE id=? AND status='pending' AND next_attempt<=?").bind(now+60000,row.id,now).run();
  if(!lock.meta.changes)continue;
  let delivered=false;
  try{
   const payload={data:[JSON.parse(row.payload)],...(env.META_CAPI_TEST_EVENT_CODE?{test_event_code:env.META_CAPI_TEST_EVENT_CODE}:{})};
   const response=await fetch('https://graph.facebook.com/v25.0/'+META_PIXEL_ID+'/events',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+env.META_CAPI_ACCESS_TOKEN},body:JSON.stringify(payload),signal:AbortSignal.timeout(6000)});
   const result=await response.json();delivered=response.ok&&result.events_received===1;
  }catch{/* Never expose tokens, matching data, or Meta response details in logs. */}
  if(delivered)await db(env).prepare("UPDATE capi_outbox SET status='sent',payload='{}',sent_at=? WHERE id=?").bind(Date.now(),row.id).run();
  else await db(env).prepare('UPDATE capi_outbox SET next_attempt=? WHERE id=?').bind(Date.now()+Math.min(3600000,60000*2**Math.min(row.attempts,6)),row.id).run();
 }
}
