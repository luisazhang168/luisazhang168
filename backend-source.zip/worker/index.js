const origins=new Set(['https://innoplasticpyrolysis.com','https://b-plastic-pyrolysis-1050.luisazhang168.chatgpt.site']);
const escapeHTML=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const json=(v,status=200)=>new Response(JSON.stringify(v),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const fail=(status,message)=>{throw Object.assign(new Error(message),{status});};
function db(env){if(!env.DB)fail(503,'Storage unavailable. Please try again later.');return env.DB;}
async function content(env){const row=await db(env).prepare('SELECT value,revision FROM content WHERE id = ?').bind('site').first();return row?{value:JSON.parse(row.value),revision:row.revision}:{value:structuredClone(DATA.defaults),revision:0};}
async function boundedBytes(req,max){const reader=req.body?.getReader();if(!reader)return new Uint8Array();const chunks=[];let size=0;while(true){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>max){await reader.cancel();fail(413,'Content is too large.');}chunks.push(value);}const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}return bytes;}
async function body(req,max=200000){const bytes=await boundedBytes(req,max);try{return JSON.parse(new TextDecoder().decode(bytes));}catch{fail(400,'Invalid request.');}}
function validContent(v){
 if(!v||typeof v!=='object'||!v.config||!v.text||!v.images||!v.meta)fail(400,'内容格式错误');
 const c=v.config;for(const k of ['company','email','whatsapp','address'])if(typeof c[k]!=='string'||c[k].length>500)fail(400,'公司信息格式错误');
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)||!/^\d{7,15}$/.test(c.whatsapp))fail(400,'请检查邮箱及 WhatsApp（仅填国际区号和数字）');
 const keys=new Set(Object.values(DATA.catalog).flatMap(p=>p.fields.map(f=>f.key)));
 for(const [k,val] of Object.entries(v.text))if(!keys.has(k)||typeof val!=='string'||val.length>6000)fail(400,'文字字段无效或过长');
 for(const [k,val] of Object.entries(v.images))if(!DATA.assets['/'+k]||typeof val!=='string'||!/^\/media\/[a-f0-9-]+\.(jpg|png|webp)$/.test(val))fail(400,'图片无效');
 for(const [k,m] of Object.entries(v.meta))if(!DATA.catalog[k]||typeof m.title!=='string'||typeof m.description!=='string'||m.title.length>200||m.description.length>500)fail(400,'搜索展示信息无效');
 // The public script consumes only these known settings.
 return {config:{company:c.company,email:c.email,whatsapp:c.whatsapp,address:c.address,heroImage:DATA.defaults.config.heroImage,factoryImage:DATA.defaults.config.factoryImage,projects:[]},text:v.text,images:v.images,meta:v.meta};
}
function render(name,v){
 let html=DATA.pages[name].replace(/<span data-cms="([^"]+)">([\s\S]*?)<\/span>/g,(all,key)=>Object.hasOwn(v.text,key)?`<span data-cms="${key}">${escapeHTML(v.text[key])}</span>`:all);
 for(const [old,url] of Object.entries(v.images)) html=html.split(old).join(escapeHTML(url));
 const c=v.config,d=DATA.defaults.config;
 for(const key of ['company','email','address'])html=html.split(escapeHTML(d[key])).join(escapeHTML(c[key]));
 html=html.replaceAll('8618953194829',c.whatsapp).replaceAll('+86 18953194829','+'+c.whatsapp);
 const meta=v.meta[name];if(meta){html=html.replace(/<title>[\s\S]*?<\/title>/,`<title>${escapeHTML(meta.title)}</title>`).replace(/(<meta name="description" content=")[^"]*/,(_,a)=>a+escapeHTML(meta.description));}
 return html;
}
async function handle(req,env){
 const url=new URL(req.url),p=url.pathname;
 if(!['GET','HEAD','POST','PUT','PATCH'].includes(req.method))return json({error:'Method not allowed'},405);
 if(!['GET','HEAD'].includes(req.method) && (!origins.has(req.headers.get('origin'))||req.headers.get('origin')!==url.origin))return json({error:'Invalid origin'},403);
 if(p==='/api/auth/login'&&req.method==='POST')return login(req,env);
 if(p==='/api/auth/logout'&&req.method==='POST')return logout(req,env);
 if(p.startsWith('/api/admin')){
  if(!await admin(req,env))return json({error:'登录已过期，请重新登录后台'},403);
  if(p==='/api/admin/content'&&req.method==='GET')return json({...await content(env),catalog:DATA.catalog,images:Object.keys(DATA.assets).filter(x=>x.startsWith('/assets/')).map(x=>x.slice(1))});
  if(p==='/api/admin/content'&&req.method==='PUT'){
   const b=await body(req),v=validContent(b.value);if(!Number.isInteger(b.revision))fail(400,'版本无效');
   const result=await db(env).prepare('INSERT INTO content (id,value,revision,updated_at) VALUES (?,?,1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value,revision=content.revision+1,updated_at=excluded.updated_at WHERE content.revision=?').bind('site',JSON.stringify(v),new Date().toISOString(),b.revision).run();
   if(!result.meta.changes)fail(409,'内容已在其他窗口更新，请先复制未保存文字，再刷新页面。');return json({revision:b.revision+1});
  }
  if(p==='/api/admin/upload'&&req.method==='POST'){
   if(!env.BUCKET)fail(503,'图片存储暂不可用');
   const bytes=await boundedBytes(req,5*1024*1024);if(bytes.length<12)fail(400,'请选择不超过5MB的 JPG、PNG 或 WebP 图片');
   let ext,type;if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255){ext='jpg';type='image/jpeg';}else if([137,80,78,71,13,10,26,10].every((b,i)=>bytes[i]===b)){ext='png';type='image/png';}else if(new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP'){ext='webp';type='image/webp';}else fail(400,'图片格式不支持');
   const key=crypto.randomUUID()+'.'+ext;await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:type}});return json({url:'/media/'+key});
  }
  if(p==='/api/admin/messages'&&req.method==='GET'){
   const page=Math.max(0,Math.min(100000,Number(url.searchParams.get('page'))||0));const rows=await db(env).prepare('SELECT * FROM messages ORDER BY created_at DESC,id DESC LIMIT 50 OFFSET ?').bind(page*50).all();const counts=await db(env).prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status='new' THEN 1 ELSE 0 END) AS unread FROM messages").first();return json({items:rows.results,...counts,page});
  }
  if(p.startsWith('/api/admin/messages/')&&req.method==='PATCH'){
   const b=await body(req,1000);if(!['new','read','replied'].includes(b.status))fail(400,'状态无效');const result=await db(env).prepare('UPDATE messages SET status=? WHERE id=?').bind(b.status,p.split('/').pop()).run();if(!result.meta.changes)fail(404,'留言不存在');return json({ok:true});
  }
  return json({error:'Not found'},404);
 }
 if(p==='/admin'||p==='/admin/'){
  if(!await admin(req,env))return loginPage();
  return new Response(Uint8Array.from(atob(DATA.assets['/admin.html'].body),c=>c.charCodeAt(0)),{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store'}});
 }
 if(p==='/api/enquiries'&&req.method==='POST'){
  const b=await body(req,16000);if(b.website)return json({ok:true});
  const limits={name:100,email:160,country:100,capacity:100,message:2500};for(const [k,max]of Object.entries(limits))if(typeof b[k]!=='string'||!b[k].trim()||b[k].length>max)fail(400,'Please complete all fields within the allowed length.');
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email))fail(400,'Please enter a valid email address.');
  if(!/^[a-f0-9-]{36}$/.test(b.id||''))fail(400,'Please refresh the page and try again.');
  const prior=await db(env).prepare('SELECT id FROM messages WHERE id=?').bind(b.id).first();if(prior)return json({ok:true});
  const hour=Math.floor(Date.now()/3600000);const ip=req.headers.get('cf-connecting-ip')||'unknown';const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(ip+':'+hour));const key=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
  const count=await db(env).prepare('INSERT INTO submission_limits (key,count,expires) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(key,(hour+2)*3600000).first();if(count.count>10)fail(429,'Too many enquiries. Please try later or contact us by email.');
  await db(env).prepare('INSERT OR IGNORE INTO messages (id,name,email,country,capacity,message,status,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(b.id,b.name.trim(),b.email.trim(),b.country.trim(),b.capacity,b.message.trim(),'new',new Date().toISOString()).run();
  await db(env).prepare('DELETE FROM submission_limits WHERE expires < ?').bind(Date.now()).run();return json({ok:true});
 }
 if(!['GET','HEAD'].includes(req.method))return json({error:'Not found'},404);
 if(p.startsWith('/media/')){if(!/^\/media\/[a-f0-9-]+\.(jpg|png|webp)$/.test(p))return new Response('Not found',{status:404});const obj=await env.BUCKET?.get(p.slice(7));if(!obj)return new Response('Not found',{status:404});return new Response(obj.body,{headers:{'content-type':obj.httpMetadata?.contentType||'application/octet-stream','cache-control':'public,max-age=31536000,immutable','x-content-type-options':'nosniff'}});}
 if(p==='/config.js') {const {value:v}=await content(env);const c={...v.config,heroImage:v.images[v.config.heroImage]||v.config.heroImage,factoryImage:v.images[v.config.factoryImage]||v.config.factoryImage};return new Response('window.SITE='+JSON.stringify(c).replaceAll('<','\\u003c')+';',{headers:{'content-type':'text/javascript','cache-control':'no-store'}});}
 const name=p==='/'?'index':p.replace(/^\//,'').replace(/\.html$/,'');if(DATA.pages[name]){const {value}=await content(env);return new Response(render(name,value),{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store'}});}
 const asset=DATA.assets[p];if(asset&&p!=='/admin.html')return new Response(Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0)),{headers:{'content-type':asset.type,'cache-control':p.includes('admin')?'no-store':'public,max-age=300','x-content-type-options':'nosniff'}});
 return new Response('Page not found',{status:404});
}
export default {async fetch(req,env){try{const res=await handle(req,env);res.headers.set('X-Content-Type-Options','nosniff');res.headers.set('Referrer-Policy','strict-origin-when-cross-origin');if(new URL(req.url).pathname.startsWith('/admin'))res.headers.set('X-Robots-Tag','noindex, nofollow');return res;}catch(e){console.error('Request failed',e.status||500,e.message);return json({error:e.status?e.message:'Service temporarily unavailable. Your changes have not been confirmed. Please try again.'},e.status||503);}}};
