import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import worker from '../dist/server/index.js';

test('CAPI requires consent; persists retries; sends once without message text',async()=>{
 const sql=new DatabaseSync(':memory:');
 for(const f of fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql')))sql.exec(fs.readFileSync('drizzle/'+f,'utf8'));
 const DB={prepare(s){const q=sql.prepare(s);let a=[];return {bind(...v){a=v;return this},async first(){return q.get(...a)||null},async all(){return {results:q.all(...a)}},async run(){return {meta:q.run(...a)}}}},async batch(statements){sql.exec('BEGIN');try{const r=[];for(const s of statements)r.push(await s.run());sql.exec('COMMIT');return r}catch(e){sql.exec('ROLLBACK');throw e}}};
 const env={DB,META_CAPI_ACCESS_TOKEN:'test-only-token'};
 const original=globalThis.fetch;let calls=0,success=false,sent;
 globalThis.fetch=async(url,options)=>{calls++;assert.equal(url,'https://graph.facebook.com/v25.0/1406803950899656/events');sent=JSON.parse(options.body);return Response.json(success?{events_received:1}:{error:{message:'temporary'}},{status:success?200:503})};
 async function submit(consent,id=crypto.randomUUID()){
  const pending=[];const response=await worker.fetch(new Request('https://innoplasticpyrolysis.com/api/enquiries',{method:'POST',headers:{origin:'https://innoplasticpyrolysis.com','user-agent':'test-browser','cf-connecting-ip':'192.0.2.1'},body:JSON.stringify({id,name:'Test',email:' TEST@example.com ',country:'Test',capacity:'Test',message:'PRIVATE MESSAGE',metaConsent:consent})}),env,{waitUntil(p){pending.push(p)}});
  await Promise.all(pending);return {id,response};
 }
 try{
  // Use an address accepted by the existing enquiry validation.
  const no=await submit(undefined);assert.equal(no.response.status,400);
  // Test with normalized input below.
  const originalFetch=worker.fetch.bind(worker);
  worker.fetch=async(req,...args)=>{if(req.method==='POST'){const b=await req.json();b.email=b.email.trim();req=new Request(req,{body:JSON.stringify(b)})}return originalFetch(req,...args)};
  const a=await submit(undefined);assert.equal(a.response.status,200);assert.equal(calls,0);
  const b=await submit('on');assert.equal(b.response.status,200);assert.equal(calls,1);
  assert.equal(sql.prepare('SELECT status FROM capi_outbox WHERE id=?').get(b.id).status,'pending');
  assert.ok(!JSON.stringify(sent).includes('PRIVATE MESSAGE'));assert.ok(!JSON.stringify(sent).includes('TEST@example.com'));
  assert.match(sent.data[0].user_data.em[0],/^[a-f0-9]{64}$/);assert.equal(sent.data[0].event_id,b.id);
  success=true;sql.prepare('UPDATE capi_outbox SET next_attempt=0').run();await submit('on',b.id);
  assert.equal(calls,2);assert.equal(sql.prepare('SELECT payload FROM capi_outbox WHERE id=?').get(b.id).payload,'{}');
  await submit('on',b.id);assert.equal(calls,2);assert.equal(sql.prepare('SELECT COUNT(*) AS n FROM messages').get().n,2);
  worker.fetch=originalFetch;
 }finally{globalThis.fetch=original;sql.close()}
});
