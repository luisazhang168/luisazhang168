# B 英文企业网站

五页纯静态网站，无数据库、无后台、无第三方前端依赖。发布文件全部位于 `dist`。

## 本地查看

直接打开 `dist/index.html`，或安装 Node.js 后运行 `node preview.cjs`，访问 http://127.0.0.1:4173。

## 部署到域名

将 `dist` **里面的所有文件**上传至支持静态网站的主机根目录（如 public_html），然后根据主机提供的记录配置域名 DNS 并启用 HTTPS。域名本身不能存储网站，还需要静态托管或服务器。无需安装 Node.js 到服务器。

## 上线前必须补齐

当前公司名 B 按要求暂用；尚未提供真实联系方式、照片和案例，因此没有编造客户、产出率、资质或案例。

1. 编辑 `dist/config.js`，填写 email、whatsapp（国际区号加号码，如 861...，不要填写示例号码）、address。
2. 将真实照片放入 `dist/assets/`，在 heroImage / factoryImage 中填写如 `assets/plant.webp`。建议使用压缩的 WebP 或 JPG。
3. 在 projects 数组中填写真实案例。示例结构如下，值需要替换为真实数据，未核实不要发布：

```js
projects: [{
  title: '真实项目英文标题',
  location: '真实国家或地区',
  description: '经过确认的英文原料、配置和运行情况',
  capacity: '实际项目处理能力及单位',
  image: 'assets/project-01.webp',
  imageAlt: '英文图片描述'
}]
```

4. 将正式公司名称替换到 `build.ps1` 的文案、页标题、品牌标识中，更新 config.js 的 company。运行 `powershell -ExecutionPolicy Bypass -File build.ps1` 重新生成页面；也可直接编辑 dist 中 HTML（再次生成会覆盖直接修改）。
5. 核实英文技术说明，补充实际型号、工况、配套与交付服务。10–50 吨/天仅为用户提供的处理范围，没有虚构细分型号。
6. 正式域名确定后可增加 canonical 与 sitemap；在发布前检查邮箱和 WhatsApp 链接。

## 询价功能

表单不会向服务器提交数据，生成草稿后可复制；配置有效公司邮箱后显示“Open email app”。发信由访客自己的邮件软件完成。没有虚假的发送成功提示。网站未配置追踪器，也不会保存访客表单内容。

## 文件

- index.html：首页
- products.html：产品与常见问题
- projects.html：案例列表，未填案例时显示真实的待发布状态
- about.html：公司介绍
- contact.html：联系方式与询价草稿
- style.css：响应式样式
- app.js：菜单、图片、案例、询价交互
- config.js：联系方式和资料配置

发布压缩包仅包含 dist 文件，不含本地预览程序或生成脚本。
