import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { parseHTML } from 'linkedom';
const pages={},catalog={},assets={};
for(const name of ['index','products','projects','about','contact']){
 const {document}=parseHTML(fs.readFileSync(`public/${name}.html`,'utf8'));
 const fields=[]; let n=0;
 function walk(el){for(const child of [...el.childNodes]){
  if(child.nodeType===3 && child.textContent.trim()){
   const key=`${name}-${n++}`;const span=document.createElement('span');span.setAttribute('data-cms',key);span.textContent=child.textContent;child.replaceWith(span);
   fields.push({key,label:el.closest('section')?.querySelector('h1,h2,h3')?.textContent?.slice(0,70)||'页眉、页脚与导航',value:span.textContent});
  }else if(child.nodeType===1 && !['SCRIPT','STYLE','TEXTAREA','SELECT','OPTION','SVG'].includes(child.tagName) && !child.matches('[data-company],#year,#hero-media,#factory-media,#email-link,#whatsapp-link,#address-text,#enquiry-form,#form-status')) walk(child);
 }}
 walk(document.body);
 catalog[name]={fields,title:document.title,description:document.querySelector('meta[name=description]')?.getAttribute('content')||''};
 pages[name]=document.toString();
}
function files(dir){for(const f of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,f.name);if(f.isDirectory())files(p);else if(!f.name.endsWith('.html')&&!['config.js'].includes(f.name)){const key='/'+path.relative('public',p).replaceAll('\\','/'); assets[key]={body:fs.readFileSync(p).toString('base64'),type:({'.jpg':'image/jpeg','.png':'image/png','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'})[path.extname(p)]||'application/octet-stream'};}}}
files('public');
assets['/admin.html']={body:fs.readFileSync('public/admin.html').toString('base64'),type:'text/html; charset=utf-8'};
const context={window:{}};vm.runInNewContext(fs.readFileSync('public/config.js','utf8'),context);
const defaults={config:context.window.SITE,text:{},images:{},meta:{}};
const output=path.resolve('dist');if(path.dirname(output)!==process.cwd()||path.basename(output)!=='dist')throw new Error('Invalid output directory');fs.rmSync(output,{recursive:true,force:true});
fs.mkdirSync('dist/server',{recursive:true});fs.mkdirSync('dist/.openai',{recursive:true});
fs.copyFileSync('.openai/hosting.json','dist/.openai/hosting.json');
fs.cpSync('drizzle','dist/.openai/drizzle',{recursive:true});
const data={pages,catalog,assets,defaults};
fs.writeFileSync('dist/server/index.js','const DATA='+JSON.stringify(data)+';\n'+fs.readFileSync('worker/capi.js','utf8')+'\n'+fs.readFileSync('worker/auth.js','utf8')+'\n'+fs.readFileSync('worker/index.js','utf8'));
console.log('Built server, content catalog, images and migrations.');
