// Reads a password from hidden stdin; prints only a salted verifier, never the password.
const crypto=require('node:crypto');
if(process.stdin.isTTY)process.stdin.setRawMode(true);
process.stdin.setEncoding('utf8');let input='';
console.log('Ready for hidden password input.');
process.stdin.on('data',chunk=>{input+=chunk;if(/[\r\n]/.test(input)){const password=input.split(/[\r\n]/)[0];const salt=crypto.randomBytes(16);const result=salt.toString('hex')+':'+crypto.pbkdf2Sync(password,salt,100000,32,'sha256').toString('hex');console.log(result);process.exit(0);}});
